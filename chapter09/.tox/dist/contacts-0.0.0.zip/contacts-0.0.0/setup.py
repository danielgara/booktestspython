from setuptools import setup

setup(name='contacts', packages=['contacts'])
